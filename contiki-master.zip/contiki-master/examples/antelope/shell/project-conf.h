#undef QUEUEBUF_CONF_NUM
#define QUEUEBUF_CONF_NUM	4

#undef NETSTACK_CONF_RDC
#define NETSTACK_CONF_RDC       nullrdc_driver

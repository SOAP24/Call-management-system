
This application is derived form rpl-udp.

It's modified to show:

* Reading out sensors from the avr-rss2 platform. Which should follow the
  Contiki conventions.

* Encode the data according to the sensd TAG format. In effect the sensd 
  GW and rest of "eco-system" as Mobile apps etc can be used for a simple
  and flexible data collection, Sink mote will be connected to sensd GW.

References and code:
https://github.com/herjulf/sensd
https://github.com/herjulf/Read-Sensors   (Android app. Also at Google Play)

  

Contiki client for sensd
========================


Contiki client connects to: 
"sensd - A WSN Internet GW, hub, agent, proxy & cloud"

For full sensd documentation and code see:
https://github.com/herjulf/sensd


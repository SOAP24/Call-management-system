Hello-sensors
=============

Simple demo to read out sensors from the RSS2 mote.

Demo uses double which has the same size as float on Atmel. We sacrifice 
some bytes for this.

Build
-----
make TARGET=avr-rss2
